let isEnabled = true; 
const isMaths = window.location.hostname.includes('maths');
const extensionName = isMaths ? "SparxMathsAI" : "SparxScienceAI";

window.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    const key = e.key.toLowerCase();
    const container = document.getElementById('gemini-overlay');

    if (isEnabled && key === 'z') {
        createGeminiWindow("Solving..."); 
        
        let prompt = "";
        if (isMaths) {
            // MATHS: Needs Code for Bookwork, but only shows 'a)' if there are multiple parts
            prompt = "Identify the Sparx Code and solve. If there is only one part, return 'CODE: [Code] | ANSWER: [Value with units]'. If there are parts a, b, c, return 'CODE: [Code] | a) [Ans] | b) [Ans]'. No sentences.";
        } else {
            // SCIENCE: No code needed, just the raw answer or list
            prompt = "Solve this. If one question, return ONLY the answer with units (e.g., 300kg). If multiple parts, return 'a) [Ans] | b) [Ans]'. One line only, no talking.";
        }

        chrome.runtime.sendMessage({ action: "capture_screen", instruction: prompt });
    }
    
    if (isEnabled && isMaths && key === 'x') {
        const lookupCode = prompt("Enter Sparx Code (e.g. 1A):");
        if (lookupCode) {
            chrome.storage.local.get([lookupCode.toUpperCase()], (result) => {
                const saved = result[lookupCode.toUpperCase()];
                createGeminiWindow(saved ? `RECALLED: ${saved}` : "Not found.");
            });
        }
    }

    if (key === 'h' && container) container.style.display = 'none';
    if (key === 'a' && container) container.style.display = 'flex';
});

chrome.runtime.onMessage.addListener((request) => {
    const contentDiv = document.getElementById('gemini-content');
    if (request.action === "save_and_display") {
        const { code, answer } = request;
        if (isMaths && code !== "N/A") {
            chrome.storage.local.set({ [code.toUpperCase()]: answer }, () => {
                // Style the box exactly like the old Quick-Cap
                if (contentDiv) contentDiv.innerHTML = `<span style="color:#00FF00">CODE: ${code}</span><br><span style="color:#00FF00">ANSWER: ${answer}</span>`;
            });
        } else {
            if (contentDiv) contentDiv.innerText = answer;
        }
    } else if (request.action === "display_response") {
        if (contentDiv) contentDiv.innerText = request.data;
    }
});

function createGeminiWindow(text) {
    let container = document.getElementById('gemini-overlay');
    if (!container) {
        container = document.createElement('div');
        container.id = 'gemini-overlay';
        container.innerHTML = `
            <div id="gemini-header">
                <span>${extensionName}</span>
                <button id="gemini-close" style="background:none; border:none; color:white; cursor:pointer;">×</button>
            </div>
            <div id="gemini-content" style="color:#00FF00; font-family:monospace; font-weight:bold;">${text}</div>
        `;
        document.body.appendChild(container);
        setupInteractions(container);
    } else {
        container.style.display = 'flex';
        document.getElementById('gemini-content').innerText = text;
    }
}

function setupInteractions(el) {
    const header = el.querySelector('#gemini-header');
    el.querySelector('#gemini-close').onclick = () => el.remove();
    let isDragging = false;
    header.onmousedown = (e) => {
        isDragging = true;
        let shiftX = e.clientX - el.getBoundingClientRect().left;
        let shiftY = e.clientY - el.getBoundingClientRect().top;
        document.onmousemove = (e) => {
            if (!isDragging) return;
            el.style.left = e.pageX - shiftX + 'px';
            el.style.top = e.pageY - shiftY + 'px';
        };
        document.onmouseup = () => { isDragging = false; document.onmousemove = null; };
    };
}