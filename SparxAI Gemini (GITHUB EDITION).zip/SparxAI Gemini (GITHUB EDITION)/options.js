document.getElementById('save').onclick = () => {
    const key = document.getElementById('apiKey').value;
    chrome.storage.local.set({ gemini_api_key: key }, () => {
        const status = document.getElementById('status');
        status.innerText = "Saved! Refresh Sparx to use.";
        setTimeout(() => { status.innerText = ""; }, 3000);
    });
};

// Load existing key
chrome.storage.local.get('gemini_api_key', (data) => {
    if (data.gemini_api_key) {
        document.getElementById('apiKey').value = data.gemini_api_key;
    }
});